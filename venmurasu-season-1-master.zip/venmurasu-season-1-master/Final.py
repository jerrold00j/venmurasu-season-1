data1 = open("Final.txt" , "w+" , encoding="utf-8")
data2 = open("Final_and_analysed1.txt" , "r+" , encoding="utf-8")
