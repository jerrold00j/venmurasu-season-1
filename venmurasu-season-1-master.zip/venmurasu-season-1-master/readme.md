```
https://venmurasu.in/ 
```

## Task 0

Fork this Repository

## Task 1

Scrape first 5 chapters

Get All words and save as a CSV file

## Task 2

Visualize Collected Data

Word count analytics,
Length of content,
Number of sentences,
Most used words,
Least used words etc

## Task 3

Identify Unique Words using NLP



